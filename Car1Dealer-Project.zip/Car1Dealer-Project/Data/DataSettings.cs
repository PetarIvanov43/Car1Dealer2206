﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Data
{
    public class DataSettings
    {
        public const string DefaultConnection = "Server=DESKTOP-QMKI0C2\\SQLEXPRESS;Database=Car1Dealer;Integrated Security=True";
    }
}
