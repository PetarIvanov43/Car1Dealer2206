﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Data
{
    public class InitialDataSets
    {
        public const string makes = "Ford, Opel, Renault";
        public const string fordModels = "Mondeo, Focus, Crown Victoria";
        public const string opelModels = "Astra, Insignia, Mokka";
        public const string renaultModels = "Clio, Megane";
        public const string vehicleTypes = "Sedan, Wagon, Coupe";
        public const string fuels = "Petrol, Diesel, Methan, Gas, Electricity";
        public const string euroStandards = "EURO1, EURO2, EURO3, EURO4, EURO5, EURO6";
        public const string gearboxes = "Maunal, Automatic, Semi-Automatic";
        public const string doorCounts = "2/3, 4/5, 6/7";
        public const string extras = "A/C, Navigation, Electrical windows, Panoramic roof, Heated seats, Electrical seats, Electrical Mirrors, Automaitc DRL, ABS, ESP, TC";
        public const string colors = "Black, White, Red, Grey, Silver, Blue, Green, Yellow";
        public const string car1 = "1, 2, 2, 1, 1987, 101, 2, 3, 3, 100321, 3, 2, 1, like new, 20000";
        public const string car2 = "2, 2, 1, 1, 3000, 280, 2, 3, 2, 60000, 3, 2, 1, almost new, 30500";
    }
}
