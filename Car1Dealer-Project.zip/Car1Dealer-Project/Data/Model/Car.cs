﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;

namespace Data.Model
{
    public class Car
    {
        [Key]
        public int Id { get; set; }

        public int MakeId { get; set; }

        public Make Make { get; set; }


        public int CarModelId { get; set; }

        public CarModel CarModel { get; set; }

        [MaxLength(50)]
        public string Modification { get; set; }

        public int TypeId { get; set; }

        public CarType Type { get; set; }

        public int FuelId { get; set; }

        public Fuel Fuel { get; set; }


        public int EngineCapacity { get; set; }
        public int EnginePower { get; set; }

        public int GearboxId { get; set; }

        public Gearbox Gearbox { get; set; }

        public int DoorsId { get; set; }

        public DoorsCount Doors { get; set; }


        public int? EuroStandardId { get; set; }

        public EuroStandard EuroStandard { get; set; }

        public int Kilometers { get; set; }


        public int? PaintId { get; set; }

        public Paint Paint { get; set; }


        public ICollection<CarExtra> CarExtras { get; set; } = new List<CarExtra>();


        public bool AdAvailable { get; set; } = true;


        [MaxLength(1000)]
        public string Information { get; set; }

        public decimal Price { get; set; }
    }
}
