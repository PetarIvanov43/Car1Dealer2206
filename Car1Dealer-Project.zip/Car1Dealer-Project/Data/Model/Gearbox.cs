﻿using System.Text;
using System.ComponentModel.DataAnnotations;

namespace Data.Model
{
    public class Gearbox
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(20)]
        public string GearboxType { get; set; }
    }
}
