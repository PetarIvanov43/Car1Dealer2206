﻿using System;
using System.Linq;
using System.Collections.Generic;
using Data;
using Data.Model;

namespace Business
{
    public class DataInitialiser
    {
        //--importing Fuels
        public static void ImportFuelTypes(Car1DealerContext context)
        {
            if (context.FuelTypes.Count() == 0)
            {
                var names = InitialDataSets.fuels.Split(", ");
                var fuelTypes = new List<Fuel>();

                foreach (var currentfuel in names)
                {
                    Fuel fuel = new Fuel();
                    fuel.FuelType = currentfuel;
                    fuelTypes.Add(fuel);
                }

                context.FuelTypes.AddRange(fuelTypes);
                context.SaveChanges();
            }
        }


        //--importing Renaults
        public static void ImportMakeRenault(Car1DealerContext context)
        {
            if (!context.Makes.Any(n => n.MakeName == "Renault"))
            {
                Make make = new Make();
                make.MakeName = "Renault";


                var names = InitialDataSets.renaultModels.Split(", ");
                var models = new List<CarModel>();

                foreach (var currentCarModel in names)
                {
                    CarModel carModel = new CarModel();
                    carModel.ModelName = currentCarModel;
                    make.CarModels.Add(carModel);
                }

                context.Makes.Add(make);
                context.SaveChanges();
            }
        }


        //--importing Fords
        public static void ImportMakeFord(Car1DealerContext context)
        {
            if (!context.Makes.Any(n => n.MakeName == "Ford"))
            {
                Make make = new Make();
                make.MakeName = "Ford";


                var names = InitialDataSets.fordModels.Split(", ");
                var models = new List<CarModel>();

                foreach (var currentCarModel in names)
                {
                    CarModel carModel = new CarModel();
                    carModel.ModelName = currentCarModel;
                    make.CarModels.Add(carModel);
                }

                context.Makes.Add(make);
                context.SaveChanges();
            }
        }


        //--importing Opels
        public static void ImportMakeOpel(Car1DealerContext context)
        {
            if (!context.Makes.Any(n => n.MakeName == "Opel"))
            {
                Make make = new Make();
                make.MakeName = "Opel";


                var names = InitialDataSets.opelModels.Split(", ");
                var models = new List<CarModel>();

                foreach (var currentCarModel in names)
                {
                    CarModel carModel = new CarModel();
                    carModel.ModelName = currentCarModel;
                    make.CarModels.Add(carModel);
                }

                context.Makes.Add(make);
                context.SaveChanges();
            }
        }


        //--importing Types
        public static void ImportVehicleTypes(Car1DealerContext context)
        {
            if (context.CarTypes.Count() == 0)
            {
                var names = InitialDataSets.vehicleTypes.Split(", ");
                var carTypes = new List<Data.Model.CarType>();

                foreach (var currentfuel in names)
                {
                    Data.Model.CarType vType = new Data.Model.CarType();
                    vType.TypeName = currentfuel;
                    carTypes.Add(vType);
                }

                context.CarTypes.AddRange(carTypes);
                context.SaveChanges();
            }
        }


        //--importing Euro Standards
        public static void ImportEuroStandards(Car1DealerContext context)
        {
            if (context.EuroStandards.Count() == 0)
            {
                var names = InitialDataSets.euroStandards.Split(", ");
                var euStds = new List<EuroStandard>();

                foreach (var currentItem in names)
                {
                    EuroStandard inst = new EuroStandard();
                    inst.EuroStandardType = currentItem;
                    euStds.Add(inst);
                }

                //euStds.Sort();

                context.EuroStandards.AddRange(euStds);
                context.SaveChanges();
            }
        }


        //--importing Gearboxes
        public static void ImportGearboxes(Car1DealerContext context)
        {
            if (context.Gearboxes.Count() == 0)
            {
                var names = InitialDataSets.gearboxes.Split(", ");
                var instList = new List<Gearbox>();

                foreach (var currentItem in names)
                {
                    Gearbox inst = new Gearbox();
                    inst.GearboxType = currentItem;
                    instList.Add(inst);
                }

                context.Gearboxes.AddRange(instList);
                context.SaveChanges();
            }
        }


        //--importing Doors
        public static void ImportDoors(Car1DealerContext context)
        {
            if (context.DoorCounts.Count() == 0)
            {
                var names = InitialDataSets.doorCounts.Split(", ");
                var instList = new List<DoorsCount>();

                foreach (var currentItem in names)
                {
                    DoorsCount inst = new DoorsCount();
                    inst.DoorsConfiguration = currentItem;
                    instList.Add(inst);
                }

                context.DoorCounts.AddRange(instList);
                context.SaveChanges();
            }
        }


        //--importing Extras
        public static void ImportExtras(Car1DealerContext context)
        {
            if (context.Extras.Count() == 0)
            {
                var names = InitialDataSets.extras.Split(", ");
                var instList = new List<Extra>();

                foreach (var currentItem in names)
                {
                    Extra inst = new Extra();
                    inst.ExtraType = currentItem;
                    instList.Add(inst);
                }


                context.Extras.AddRange(instList);
                context.SaveChanges();
            }
        }


        //--importing Colors
        public static void ImportColors(Car1DealerContext context)
        {
            if (context.Paints.Count() == 0)
            {
                var names = InitialDataSets.colors.Split(", ");
                var instList = new List<Paint>();

                foreach (var currentItem in names)
                {
                    Paint inst = new Paint();
                    inst.Color = currentItem;
                    instList.Add(inst);
                }

                context.Paints.AddRange(instList);
                context.SaveChanges();
            }
        }

        //--add car1

        public static void ImportCar1(Car1DealerContext context)
        {
            if (context.Cars.Count() < 1)
            {
                Car car1 = new Car();

                var carData = InitialDataSets.car1.Split(", ");

                car1.MakeId = int.Parse(carData[0]);
                car1.CarModelId = int.Parse(carData[1]);
                car1.TypeId = int.Parse(carData[2]);
                car1.FuelId = int.Parse(carData[3]);
                car1.EngineCapacity = int.Parse(carData[4]);
                car1.EnginePower = int.Parse(carData[5]);
                car1.GearboxId = int.Parse(carData[6]);
                car1.DoorsId = int.Parse(carData[7]);
                car1.EuroStandardId = int.Parse(carData[8]);
                car1.Kilometers = int.Parse(carData[9]);
                car1.PaintId = int.Parse(carData[10]);
                car1.Information = carData[13];
                car1.Price = decimal.Parse(carData[14]);

                context.Cars.Add(car1);

                context.SaveChanges();


                CarExtra carExtra1 = new CarExtra();
                carExtra1.CarId = context.Cars.OrderByDescending(c => c.Id).FirstOrDefault().Id;
                carExtra1.ExtraId = int.Parse(carData[11]);

                CarExtra carExtra2 = new CarExtra();
                carExtra2.CarId = context.Cars.OrderByDescending(c => c.Id).FirstOrDefault().Id;
                carExtra2.ExtraId = int.Parse(carData[12]);

                context.CarsExtras.AddRange(carExtra1, carExtra2);
                
                context.SaveChanges();



                Car car2 = new Car();

                var carData2 = InitialDataSets.car2.Split(", ");

                car2.MakeId = int.Parse(carData2[0]);
                car2.CarModelId = int.Parse(carData2[1]);
                car2.TypeId = int.Parse(carData2[2]);
                car2.FuelId = int.Parse(carData2[3]);
                car2.EngineCapacity = int.Parse(carData2[4]);
                car2.EnginePower = int.Parse(carData2[5]);
                car2.GearboxId = int.Parse(carData2[6]);
                car2.DoorsId = int.Parse(carData2[7]);
                car2.EuroStandardId = int.Parse(carData2[8]);
                car2.Kilometers = int.Parse(carData2[9]);
                car2.PaintId = int.Parse(carData2[10]);
                car2.Information = carData2[13];
                car2.Price = decimal.Parse(carData2[14]);

                context.Cars.Add(car2);

                context.SaveChanges();

                CarExtra car2Extra1 = new CarExtra();
                car2Extra1.CarId = context.Cars.OrderByDescending(c => c.Id).FirstOrDefault().Id;
                car2Extra1.ExtraId = int.Parse(carData2[11]);

                CarExtra car2Extra2 = new CarExtra();
                car2Extra2.CarId = context.Cars.OrderByDescending(c => c.Id).FirstOrDefault().Id;
                car2Extra2.ExtraId = int.Parse(carData2[12]);

                context.CarsExtras.AddRange(car2Extra1, car2Extra2);

                context.SaveChanges();
            }
        }


    }
}
