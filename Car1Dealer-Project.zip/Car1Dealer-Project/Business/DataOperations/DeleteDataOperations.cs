﻿using Data;
using Data.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Business.DataOperations
{
    public class DeleteDataOperations
    {
        public string DeleteCarFromDB(Car1DealerContext context, int id)
        {
            int carsCount = context.Cars.Count();
            string message = "The car failed to remove";

            Car deletedCar = context.Cars.FirstOrDefault(c => c.Id == id);
            context.Cars.Remove(deletedCar);

            context.SaveChanges();

            int newCarsCount = context.Cars.Count();

            if (carsCount > newCarsCount)
            {
                message = $"The car is successfully removed!";
            }

            return message;

        }
    }
}
