﻿using Business.ViewModels;
using Data;
using Data.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Business.DataOperations
{
    public class UserOperations
    {
        public bool IsValidUser (Car1DealerContext context, UserInfoModel user)
        {
            bool isValid = false;

            User currentUser = context.Users.FirstOrDefault(u =>
                u.Username == user.Username
                && u.Password == user.Password
                && u.IsActive
                );

            if (currentUser != null)
            {
                isValid = true;
            }

            return isValid;
        }

        public bool IsValidAdmin(Car1DealerContext context, UserInfoModel user)
        {
            bool isValid = false;

            User currentUser = context.Users.FirstOrDefault(u =>
                u.Username == user.Username
                && u.Password == user.Password
                && u.IsAdmin
                && u.IsActive
                );

            if (currentUser != null)
            {
                isValid = true;
            }

            return isValid;
        }

        public string AddUser(Car1DealerContext context, UserInfoModel admiInfo, UserInfoModel newUserInfo)
        {
            string message = "Only registered administrator can add users.";

            if (IsValidAdmin(context, admiInfo))
            {
                int usersWithCurrentUsername = context.Users.Where(u => u.Username == newUserInfo.Username).Count();

                if (usersWithCurrentUsername > 0)
                {
                    message = "The username allready exists.";
                }

                else
                {
                    User newUser = new User();
                    newUser.Username = newUserInfo.Username;
                    newUser.Password = newUserInfo.Password;
                    newUser.IsActive = true;
                    newUser.IsActive = false;

                    context.Add(newUser);
                    context.SaveChanges();

                    message = "New user is added successfully.";
                }                
            }
            
            return message;
        }
    }
}
