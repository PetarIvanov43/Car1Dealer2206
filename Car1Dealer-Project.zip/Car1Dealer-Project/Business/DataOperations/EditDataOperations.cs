﻿using Business.ViewModels;
using Data;
using Data.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Business.DataOperations
{
    public class EditDataOperations
    {
        public string EditCarFromDB(Car1DealerContext context, CarFullInfoModel addCarInfoModel)
        {

            Car carToAdd = context.Cars.FirstOrDefault(i => i.Id == addCarInfoModel.Id);

            List<CarExtra> deletedExtras = context.CarsExtras.Where(e => e.CarId == addCarInfoModel.Id).ToList();
            context.CarsExtras.RemoveRange(deletedExtras);

            context.SaveChanges();

            int makeId = context.Makes
                    .FirstOrDefault(m => m.MakeName == addCarInfoModel.Make)
                    .Id;
            carToAdd.MakeId = makeId;

            int modelId = context.CarModels
                    .FirstOrDefault(m => m.ModelName == addCarInfoModel.CarModel)
                    .Id;
            carToAdd.CarModelId = modelId;

            int typeId = context.CarTypes
                    .FirstOrDefault(m => m.TypeName == addCarInfoModel.Type)
                    .Id;
            carToAdd.TypeId = typeId;

            int fuelId = context.FuelTypes
                    .FirstOrDefault(m => m.FuelType == addCarInfoModel.Fuel)
                    .Id;
            carToAdd.FuelId = fuelId;

            int gearboxId = context.Gearboxes
                    .FirstOrDefault(m => m.GearboxType == addCarInfoModel.Gearbox)
                    .Id;
            carToAdd.GearboxId = gearboxId;

            if (!String.IsNullOrEmpty(addCarInfoModel.EuroStandard))
            {
                int euroStandardId = context.EuroStandards
                        .FirstOrDefault(m => m.EuroStandardType == addCarInfoModel.EuroStandard)
                        .Id;
                carToAdd.EuroStandardId = euroStandardId;
            }

            int doorsId = context.DoorCounts
                    .FirstOrDefault(m => m.DoorsConfiguration == addCarInfoModel.Doors)
                    .Id;
            carToAdd.DoorsId = doorsId;

            if (!String.IsNullOrEmpty(addCarInfoModel.Paint))
            {
                int paintsId = context.Paints
                    .FirstOrDefault(m => m.Color == addCarInfoModel.Paint)
                    .Id;
                carToAdd.PaintId = doorsId;
            }


            carToAdd.Modification = addCarInfoModel.Modification;
            carToAdd.EngineCapacity = addCarInfoModel.EngineCapacity;
            carToAdd.EnginePower = addCarInfoModel.EnginePower;
            carToAdd.Kilometers = addCarInfoModel.Kilometers;
            carToAdd.Price = addCarInfoModel.Price;
            carToAdd.Information = addCarInfoModel.Information;

            context.SaveChanges();

            int addedCarId = context.Cars.OrderByDescending(c => c.Id == addCarInfoModel.Id).FirstOrDefault().Id;

            var carExtrasToDelete = context.CarsExtras.Where(e => e.CarId == addedCarId).ToList();
            context.CarsExtras.RemoveRange(carExtrasToDelete);

            context.SaveChanges();

            List<CarExtra> carExtrasToAdd = new List<CarExtra>();

            foreach (var item in addCarInfoModel.CarExtras)
            {
                CarExtra currentCarExtra = new CarExtra();
                currentCarExtra.CarId = addedCarId;
                int currentExtraId = context.Extras
                    .FirstOrDefault(e => e.ExtraType == item)
                    .Id;
                currentCarExtra.ExtraId = currentExtraId;

                context.CarsExtras.Add(currentCarExtra);
            }


            context.SaveChanges();

            string message = $"Successfully edited car info";

            return message;
        }

        public string SellCar(Car1DealerContext context, int id)
        {
            Car carToSell = context.Cars.FirstOrDefault(i => i.Id == id);

            carToSell.AdAvailable = false;

            context.SaveChanges();

            string message = $"Successfully saved DB change: Sell car";

            return message;
        }
    }
}
