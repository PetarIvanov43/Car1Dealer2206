﻿using Business.ViewModels;
using Data;
using Data.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Business.DataOperations
{
    public class GetDataOperations
    {

        //public bool CheckCarAvailabilityById(Car1DealerContext context, int id)
        //{
        //    int count = context.Cars.Where(c => c.Id == id).Count();
        //    if (count == 0)
        //    {
        //        return false;
        //    }
        //    else
        //    {
        //        return true;
        //    }
        //}

        public bool CheckCarAvailabilityById(Car1DealerContext context, int id)
        {
            Car car = context.Cars.FirstOrDefault(c => c.Id == id);

            if (car != null)
            {
                return car.AdAvailable;
            }

            else
            {
                return false;
            }
        }

        public List<string> GetAllMakes(Car1DealerContext context)
        {
            List<string> makesStr = context.Makes.Select(m => m.MakeName).ToList();
            makesStr.Sort();
            return makesStr;
        }
        public static List<string> GetAllModelsForMake(Car1DealerContext context, string make)
        {
            List<string> makesStr = context.CarModels
                .Where(m => m.Make.MakeName == make)
                .Select(m => m.ModelName)
                .ToList();

            makesStr.Sort();
            return makesStr;
        }
        public List<string> GetAllFuels(Car1DealerContext context)
        {
            return context.FuelTypes.Select(f => f.FuelType).ToList();
        }
        public List<string> GetAllTypes(Car1DealerContext context)
        {
            List<string> typesStr = context.CarTypes.Select(t => t.TypeName).ToList();
            typesStr.Sort();
            return typesStr;
        }
        public List<string> GetAllGearboxs(Car1DealerContext context)
        {
            List<string> gearboxesStr = context.Gearboxes.Select(g => g.GearboxType).ToList();
            gearboxesStr.Sort();
            return gearboxesStr;
        }


        public List<string> GetAllDoors(Car1DealerContext context)
        {
            List<string> doorsStr = context.DoorCounts.Select(d => d.DoorsConfiguration).ToList();
            doorsStr.Sort();
            return doorsStr;
        }
        public List<string> GetAllExtras(Car1DealerContext context)
        {
            List<string> extrasStr = context.Extras.Select(e => e.ExtraType).ToList();
            extrasStr.Sort();
            return extrasStr;
        }

        public List<string> GetAllEuroStandards(Car1DealerContext context)
        {
            List<string> euroStandardsStr = context.EuroStandards.Select(e => e.EuroStandardType).ToList();
            euroStandardsStr.Sort();
            return euroStandardsStr;
        }


        public List<string> GetAllPaints(Car1DealerContext context)
        {
            List<string> paintsStr = context.Paints.Select(e => e.Color).ToList();
            paintsStr.Sort();
            return paintsStr;
        }

        public List<CarPreviewModel> GetPreviewInfo(Car1DealerContext context, CarSearchDataModel searchCriteria)
        {
            var query = context.Cars
                .Where(c => c.AdAvailable)
                .Where(m => string.IsNullOrEmpty(searchCriteria.SelectedMake) || searchCriteria.SelectedMake == "(no)" || m.Make.MakeName == searchCriteria.SelectedMake)
                .Where(m => string.IsNullOrEmpty(searchCriteria.SelectedModel) || searchCriteria.SelectedModel == "(no)" || m.CarModel.ModelName == searchCriteria.SelectedModel)
                .Where(f => string.IsNullOrEmpty(searchCriteria.SelectedFuel) || searchCriteria.SelectedFuel == "(no)" || f.Fuel.FuelType == searchCriteria.SelectedFuel)
                .Where(d => string.IsNullOrEmpty(searchCriteria.SelectedDoors) || searchCriteria.SelectedDoors == "(no)" || d.Doors.DoorsConfiguration == searchCriteria.SelectedDoors)
                .Where(t => string.IsNullOrEmpty(searchCriteria.SelectedType) || searchCriteria.SelectedType == "(no)" || t.Type.TypeName == searchCriteria.SelectedType)
                .Where(g => string.IsNullOrEmpty(searchCriteria.SelectedGearbox) || searchCriteria.SelectedGearbox == "(no)" || g.Gearbox.GearboxType == searchCriteria.SelectedGearbox)
                .Where(hp => searchCriteria.MinEnginePower == 0 || hp.EnginePower >= searchCriteria.MinEnginePower)
                .Where(hp => searchCriteria.MaxEnginePower == 0 || hp.EnginePower <= searchCriteria.MaxEnginePower)
                .Where(p => searchCriteria.MinPrice == 0 || p.Price >= searchCriteria.MinPrice)
                .Where(p => searchCriteria.MaxPrice == 0 || p.Price <= searchCriteria.MaxPrice);

            foreach (var extra in searchCriteria.SelectedExtras)
            {
                query = query
                    .Where(c => c.CarExtras.Select(e => e.Extra.ExtraType).Any(x => x == extra));
            }

            query = query
                .OrderBy(c => c.Price);

            var models = query
               .Select(c => new CarPreviewModel(
                    c.Id,
                    c.Make.MakeName,
                    c.CarModel.ModelName,
                    c.Modification,
                    c.Kilometers,
                    c.Fuel.FuelType,
                    c.Price
                ))
               .ToList();

            return models;
        }



        public CarFullInfoModel GetFullInfo(Car1DealerContext context, int id)
        {
            var resultCarInfo = context.Cars
                .Where(c => c.Id == id)
                .Select(c => new CarFullInfoModel(
                    c.Id,
                    c.Make.MakeName,
                    c.CarModel.ModelName,
                    c.Modification,
                    c.Fuel.FuelType,
                    c.Type.TypeName,
                    c.EngineCapacity,
                    c.EnginePower,
                    c.Gearbox.GearboxType,
                    c.EuroStandard.EuroStandardType,
                    c.Doors.DoorsConfiguration,
                    c.Kilometers,
                    c.Paint.Color,
                    c.Information,
                    c.Price
                ))
                .FirstOrDefault();

            if (resultCarInfo != null)
            {
                List<string> extras = context.CarsExtras
                .Where(c => c.CarId == id)
                .Select(e => e.Extra.ExtraType)
                .ToList();

                extras.Sort();

                resultCarInfo.CarExtras = extras;
            }

            return resultCarInfo;
        }
    }
}
