﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Business;
using Business.ViewModels;
using Business.DataOperations;
using Data;

namespace Car1Dealer
{
    public partial class CarAd : Form
    {
        EditDataOperations EditDataOperations = new EditDataOperations();
        GetDataOperations GetDataOperations = new GetDataOperations();
        CarFullInfoModel adCar = new CarFullInfoModel();
        
        public CarAd()
        {
            InitializeComponent();

            using var db = new Car1DealerContext();

            string extrasToString = "";

            

            adCar = GetDataOperations.GetFullInfo(db, Form1.carId);


            for (int i = 0; i < adCar.CarExtras.Count; i++)
            {
                if (i != 0)
                {
                    extrasToString = $"{extrasToString}, {adCar.CarExtras[i]}";
                }
                else
                {
                    extrasToString = adCar.CarExtras[i];
                }
            }

            labelMake.Text = $"{adCar.Make}";
            labelModelSpec.Text = $"{adCar.CarModel} {adCar.Modification}";
            labelKM.Text = $"{adCar.Kilometers} Km";
            labelFuel.Text = $"{adCar.Fuel}";
            labelPrice.Text = $"{adCar.Price} $";
            labelDoors.Text = $"{adCar.Doors}";
            labelEngCap.Text = $"{adCar.EngineCapacity} cm²";
            labelEngHP.Text = $"{adCar.EnginePower} hp";
            labelEU.Text = $"{adCar.EuroStandard}";
            labelGearbox.Text = $"{adCar.Gearbox}";
            labelInfo.Text = $"{adCar.Information}";
            labelPaint.Text = $"{adCar.Paint}";
            labelExtras.Text = $"{extrasToString}";
            labelType.Text = $"{adCar.Type}";

        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            EditingCar carEditForm = new EditingCar();
            carEditForm.Show();
            this.Hide();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DeleteAsk delForm = new DeleteAsk();
            this.Hide();
            delForm.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void btnSell_Click(object sender, EventArgs e)
        {
            using var db = new Car1DealerContext();

            string message = EditDataOperations.SellCar(db, adCar.Id);
            MessageBox.Show(message);
            this.Hide();
        }
    }
}
