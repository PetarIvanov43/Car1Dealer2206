﻿using Business.DataOperations;
using Business.ViewModels;
using Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Car1Dealer
{
    public partial class DeleteAsk : Form
    {
        DeleteDataOperations DeleteDataOperations = new DeleteDataOperations();
        public DeleteAsk()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void btnProceed_Click(object sender, EventArgs e)
        {
            using var db = new Car1DealerContext();


            string message = DeleteDataOperations.DeleteCarFromDB(db, Form1.carId);

            this.Hide();
            MessageBox.Show(message);
        }
    }
}
