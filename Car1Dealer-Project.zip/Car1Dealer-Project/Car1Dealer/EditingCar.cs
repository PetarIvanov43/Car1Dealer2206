﻿using Business;
using Business.ViewModels;
using Business.DataOperations;
using Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Car1Dealer
{
    public partial class EditingCar : Form
    {
        GetDataOperations GetDataOperations = new GetDataOperations();
        AddDataOperations AddDataOperations = new AddDataOperations();
        EditDataOperations EditDataOperations = new EditDataOperations();


        EditingExtras editingExtras = new EditingExtras();
        public EditingCar()
        {
            InitializeComponent();

            using var db = new Car1DealerContext();


            cmbMake.Items.Add("(no)");
            foreach (var item in GetDataOperations.GetAllMakes(db))
            {
                cmbMake.Items.Add(item);
            }

            cmbFuel.Items.Add("(no)");
            foreach (var item in GetDataOperations.GetAllFuels(db))
            {
                cmbFuel.Items.Add(item);
            }

            cmbGearbox.Items.Add("(no)");
            foreach (var item in GetDataOperations.GetAllGearboxs(db))
            {
                cmbGearbox.Items.Add(item);
            }

            cmbDoors.Items.Add("(no)");
            foreach (var item in GetDataOperations.GetAllDoors(db))
            {
                cmbDoors.Items.Add(item);
            }

            cmbType.Items.Add("(no)");
            foreach (var item in GetDataOperations.GetAllTypes(db))
            {
                cmbType.Items.Add(item);
            }

            cmbEuroStandard.Items.Add("(no)");
            foreach (var item in GetDataOperations.GetAllEuroStandards(db))
            {
                cmbEuroStandard.Items.Add(item);
            }

            cmbPaint.Items.Add("(no)");
            foreach (var item in GetDataOperations.GetAllPaints(db))
            {
                cmbPaint.Items.Add(item);
            }

            
            CarFullInfoModel adCar = GetDataOperations.GetFullInfo(db, Form1.carId);

            cmbMake.SelectedItem = adCar.Make;
            cmbModel.SelectedItem = adCar.CarModel;
            cmbFuel.SelectedItem = adCar.Fuel;
            txtModification.Text = adCar.Modification;
            cmbDoors.SelectedItem = adCar.Doors;
            cmbGearbox.SelectedItem = adCar.Gearbox;
            cmbType.SelectedItem = adCar.Type;
            txtCapacity.Text = adCar.EngineCapacity.ToString();
            txtHP.Text = adCar.EnginePower.ToString();
            txtKilometers.Text = adCar.Kilometers.ToString();
            cmbEuroStandard.SelectedItem = adCar.EuroStandard;
            cmbPaint.SelectedItem = adCar.Paint;
            txtPrice.Text = adCar.Price.ToString();
            txtInfo.Text = adCar.Information;
        }

        private void cmbMake_SelectedIndexChanged(object sender, EventArgs e)
        {

            using var db = new Car1DealerContext();

            string a = cmbMake.SelectedItem.ToString();

            cmbModel.Items.Clear();

            foreach (var item in GetDataOperations.GetAllModelsForMake(db, a))
            {
                cmbModel.Items.Add(item);
            }
        }

        private void btnExtras_Click(object sender, EventArgs e)
        {
            editingExtras.Show();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            using var db = new Car1DealerContext();

            int capacity;
            bool successCapacity = int.TryParse(txtCapacity.Text, out capacity);
            if (!successCapacity || capacity < 0)
            {
                capacity = 0;
            }

            int hp;
            bool successHp = int.TryParse(txtHP.Text, out hp);
            if (!successHp || hp < 0)
            {
                hp = 0;
            }

            int kilometers;
            bool successKilometers = int.TryParse(txtKilometers.Text, out kilometers);
            if (!successKilometers || kilometers < 0)
            {
                kilometers = 0;
            }

            decimal price;
            bool successPrice = decimal.TryParse(txtPrice.Text, out price);
            if (!successPrice || price < 0)
            {
                price = 0;
            }


            string? selectedMake = cmbMake.SelectedItem != null ? cmbMake.SelectedItem.ToString() : null;
            string? selectedModel = cmbModel.SelectedItem != null ? cmbModel.SelectedItem.ToString() : null;
            string? selectedModification = txtModification.Text != null ? txtModification.Text : null;
            string? selectedType = cmbType.SelectedItem != null ? cmbType.SelectedItem.ToString() : null;
            string? selectedFuel = cmbFuel.SelectedItem != null ? cmbFuel.SelectedItem.ToString() : null;
            string? selectedGearbox = cmbGearbox.SelectedItem != null ? cmbGearbox.SelectedItem.ToString() : null;
            string? selectedEuroStandard = cmbEuroStandard.SelectedItem != null ? cmbEuroStandard.SelectedItem.ToString() : null;
            string? selectedDoors = cmbDoors.SelectedItem != null ? cmbDoors.SelectedItem.ToString() : null;
            string? selectedPaint = cmbPaint.SelectedItem != null ? cmbPaint.SelectedItem.ToString() : null;
            string? selectedInformation = txtInfo.Text != null ? txtInfo.Text : null;


            if (String.IsNullOrEmpty(selectedMake))
            {
                MessageBox.Show($"Field Make is required");
                return;
            }
            else if (String.IsNullOrEmpty(selectedModel))
            {
                MessageBox.Show($"Field Model is required");
                return;
            }
            else if (String.IsNullOrEmpty(selectedType))
            {
                MessageBox.Show($"Field Type is required");
                return;
            }
            else if (String.IsNullOrEmpty(selectedFuel))
            {
                MessageBox.Show($"Field Fuel is required");
                return;
            }
            else if (String.IsNullOrEmpty(selectedGearbox))
            {
                MessageBox.Show($"Field Gearbox is required");
                return;
            }
            else if (hp == 0)
            {
                MessageBox.Show($"Field Engine Horsepower is required");
                return;
            }
            else if (String.IsNullOrEmpty(selectedDoors))
            {
                MessageBox.Show($"Field Doors is required");
                return;
            }
            else if (price == 0)
            {
                MessageBox.Show($"Field Price is required");
                return;
            }
            else
            {
                CarFullInfoModel addCarInfoModel = new CarFullInfoModel();
                addCarInfoModel.Make = selectedMake;
                addCarInfoModel.CarModel = selectedModel;
                addCarInfoModel.Modification = selectedModification;
                addCarInfoModel.Type = selectedType;
                addCarInfoModel.Fuel = selectedFuel;
                addCarInfoModel.Gearbox = selectedGearbox;
                addCarInfoModel.EngineCapacity = capacity;
                addCarInfoModel.EnginePower = hp;
                addCarInfoModel.Kilometers = kilometers;
                addCarInfoModel.EuroStandard = selectedEuroStandard;
                addCarInfoModel.Doors = selectedDoors;
                addCarInfoModel.Paint = selectedPaint;
                addCarInfoModel.CarExtras = Form1.extras;
                addCarInfoModel.Price = price;
                addCarInfoModel.Information = selectedInformation;
                addCarInfoModel.Id = Form1.carId;

                string message = EditDataOperations.EditCarFromDB(db, addCarInfoModel);

                MessageBox.Show(message);
                this.Hide();

                Form1.extras.Clear();
            }
        }
    }
}
