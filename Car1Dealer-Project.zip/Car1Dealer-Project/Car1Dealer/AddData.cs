﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Car1Dealer
{
    public partial class AddData : Form
    {
        public AddData()
        {
            InitializeComponent();
        }

        private void btnMake_Click(object sender, EventArgs e)
        {
            AddMake addMake = new AddMake();
            addMake.Show();
            this.Hide();
        }

        private void btnModel_Click(object sender, EventArgs e)
        {
            AddModel addModel = new AddModel();
            addModel.Show();
            this.Hide();
        }

        private void btnType_Click(object sender, EventArgs e)
        {
            AddType addType = new AddType();
            addType.Show();
            this.Hide();
        }

        private void btnExtra_Click(object sender, EventArgs e)
        {
            AddExtras addExtra = new AddExtras();
            addExtra.Show();
            this.Hide();
        }

        private void btnPaint_Click(object sender, EventArgs e)
        {
            AddPaint addPaint = new AddPaint();
            addPaint.Show();
            this.Hide();
        }
    }
}
