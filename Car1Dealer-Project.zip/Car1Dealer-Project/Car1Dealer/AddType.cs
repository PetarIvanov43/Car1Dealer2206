﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Business.DataOperations;
using Data;

namespace Car1Dealer
{
    public partial class AddType : Form
    {
        AddDataOperations AddDataOperations = new AddDataOperations();
        public AddType()
        {
            InitializeComponent();

            using var db = new Car1DealerContext();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using var db = new Car1DealerContext();
            string message = AddDataOperations.AddNewTypeToDB(db, textBox1.Text);
            this.Hide();
            MessageBox.Show(message);
        }
    }
}
