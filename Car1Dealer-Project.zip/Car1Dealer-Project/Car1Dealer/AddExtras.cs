﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Data;
using Business.DataOperations;

namespace Car1Dealer
{
    public partial class AddExtras : Form
    {
        AddDataOperations AddDataOperations = new AddDataOperations();
        public AddExtras()
        {
            InitializeComponent();

            using var db = new Car1DealerContext();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using var db = new Car1DealerContext();
            string message = AddDataOperations.AddNewExtraToDB(db, textBox1.Text);
            this.Hide();
            MessageBox.Show(message);
        }
    }
}
