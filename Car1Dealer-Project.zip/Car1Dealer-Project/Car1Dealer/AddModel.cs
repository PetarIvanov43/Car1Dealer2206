﻿using Business.DataOperations;
using Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Car1Dealer
{
    public partial class AddModel : Form
    {
        GetDataOperations GetDataOperations = new GetDataOperations();
        AddDataOperations AddDataOperations = new AddDataOperations();

        public AddModel()
        {
            InitializeComponent();

            using var db = new Car1DealerContext();
            foreach (var item in GetDataOperations.GetAllMakes(db))
            {
                comboBox1.Items.Add(item);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using var db = new Car1DealerContext();
            string message = AddDataOperations.AddNewModelToDB(db, comboBox1.SelectedItem.ToString(), textBox1.Text);
            this.Hide();
            MessageBox.Show(message);
        }
    }
}
