﻿using Business.DataOperations;
using Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Car1Dealer
{
    public partial class AddPaint : Form
    {
        AddDataOperations AddDataOperations = new AddDataOperations();
        public AddPaint()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            using var db = new Car1DealerContext();
            string message = AddDataOperations.AddNewPaintToDB(db, textBox1.Text);
            this.Hide();
            MessageBox.Show(message);
        }
    }
}
