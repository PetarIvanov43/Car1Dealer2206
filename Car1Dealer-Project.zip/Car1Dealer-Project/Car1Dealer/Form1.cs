﻿using Business;
using Business.DataOperations;
using Business.ViewModels;
using Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;


namespace Car1Dealer
{

    public partial class Form1 : Form
    {
        public static int carId;
        public static List<string> extras = new List<string>();

        GetDataOperations GetDataOperations = new GetDataOperations();

        Extras extrasForm = new Extras();
        public Form1()
        {
            InitializeComponent();

            //start DB
            using var db = new Car1DealerContext();
            db.Database.Migrate();
            //start DB


            DataInitialiser.ImportFuelTypes(db);
            DataInitialiser.ImportMakeRenault(db);
            DataInitialiser.ImportMakeOpel(db);
            DataInitialiser.ImportMakeFord(db);
            DataInitialiser.ImportVehicleTypes(db);
            DataInitialiser.ImportEuroStandards(db);
            DataInitialiser.ImportGearboxes(db);
            DataInitialiser.ImportDoors(db);
            DataInitialiser.ImportColors(db);
            DataInitialiser.ImportExtras(db);
            DataInitialiser.ImportCar1(db);



            //comboboxes???

            cmbMake.Items.Add("(no)");
            foreach (var item in GetDataOperations.GetAllMakes(db))
            {
                cmbMake.Items.Add(item);
            }

            cmbFuel.Items.Add("(no)");
            foreach (var item in GetDataOperations.GetAllFuels(db))
            {
                cmbFuel.Items.Add(item);
            }

            cmbGearbox.Items.Add("(no)");
            foreach (var item in GetDataOperations.GetAllGearboxs(db))
            {
                cmbGearbox.Items.Add(item);
            }

            cmbDoors.Items.Add("(no)");
            foreach (var item in GetDataOperations.GetAllDoors(db))
            {
                cmbDoors.Items.Add(item);
            }

            cmbType.Items.Add("(no)");
            foreach (var item in GetDataOperations.GetAllTypes(db))
            {
                cmbType.Items.Add(item);
            }




        }


        //void for click button custom event
        public void ClickedButton(object sender, EventArgs e)
        {
            Button clickedButton = (Button)sender;
            int a = int.Parse(clickedButton.Tag.ToString());
            Form1.carId = a;

            using var db = new Car1DealerContext();

            if (GetDataOperations.CheckCarAvailabilityById(db, a))
            {
                CarAd carAdFrom = new CarAd();
                carAdFrom.Show();
            }
            else
            {
                MessageBox.Show("This car is not existing!" +
                    "\n Try refreshing the page by clicking Search button again!");
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            //
            using var db = new Car1DealerContext();
            //

            CarSearchDataModel searchCriteria = new CarSearchDataModel();

            int maxHp;
            bool successMaxHp = int.TryParse(txtMaxHp.Text, out maxHp);
            if (!successMaxHp || maxHp < 0)
            {
                maxHp = 0;
            }

            int minHp;
            bool successMinHp = int.TryParse(txtMinHp.Text, out minHp);
            if (!successMinHp || maxHp < 0 || minHp > maxHp)
            {
                if (maxHp != 0)
                {
                    minHp = 0;
                }
            }

            decimal maxPrice;
            bool successMaxPrice = decimal.TryParse(txtMaxPrice.Text, out maxPrice);
            if (!successMaxPrice || maxPrice < 0)
            {
                maxPrice = 0;
            }

            decimal minPrice;
            bool successMinPrice = decimal.TryParse(txtMinPrice.Text, out minPrice);
            if (!successMinPrice || maxPrice < 0 || minPrice > maxPrice)
            {
                if (maxPrice != 0)
                {
                    minPrice = 0;
                }
            }

            searchCriteria.MaxEnginePower = maxHp;
            searchCriteria.MinEnginePower = minHp;
            searchCriteria.MaxPrice = maxPrice;
            searchCriteria.MinPrice = minPrice;

            searchCriteria.SelectedMake = cmbMake.SelectedItem != null ? cmbMake.SelectedItem.ToString() : null;
            searchCriteria.SelectedModel = cmbModel.SelectedItem != null ? cmbModel.SelectedItem.ToString() : null;
            searchCriteria.SelectedFuel = cmbFuel.SelectedItem != null ? cmbFuel.SelectedItem.ToString() : null;
            searchCriteria.SelectedFuel = cmbDoors.SelectedItem != null ? cmbDoors.SelectedItem.ToString() : null;
            searchCriteria.SelectedType = cmbType.SelectedItem != null ? cmbType.SelectedItem.ToString() : null;
            searchCriteria.SelectedGearbox = cmbGearbox.SelectedItem != null ? cmbGearbox.SelectedItem.ToString() : null;
            searchCriteria.SelectedExtras = extras;



            flowLayoutPanel1.Controls.Clear();

            List<string> carPreviewInfos = new List<string>();
            List<CarPreviewModel> carPreviewModels = GetDataOperations.GetPreviewInfo(db, searchCriteria);

            foreach (var car in carPreviewModels)
            {
                string currentCarPreview = $"{car.Make} {car.CarModel} - {car.Modification} \n{car.Fuel} {car.Kilometers} - {car.Price}";
                carPreviewInfos.Add(currentCarPreview);
            }


            int count = carPreviewModels.Count();
            for (int i = 0; i < count; i++)
            {
                CarPreviewModel currentCar = carPreviewModels[i];
                Button newButton = new Button();
                int currentCarId = currentCar.Id;
                newButton.BackColor = Color.FromArgb(240, 108, 0);
                newButton.Font = new Font("Rajdhani", 13, FontStyle.Bold, GraphicsUnit.Point);
                newButton.Size = new Size(250, 120);
                newButton.Cursor = Cursors.Hand;
                newButton.FlatStyle = FlatStyle.Popup;
                flowLayoutPanel1.Controls.Add(newButton);
                newButton.Text = $"{currentCar.Make} {currentCar.CarModel}"
                    //+ "- {currentCar.Modification} " 
                    //+ $"\n KMs: {currentCar.Kilometers} "
                    + $"\n Fuel: {currentCar.Fuel}" 
                    + $"\n Price: {currentCar.Price}$"
                    ;

                newButton.Click += ClickedButton;
                newButton.Tag = currentCarId;
            }

        }

        private void btnAddAdv_Click(object sender, EventArgs e)
        {
            AddingCar carAddForm = new AddingCar();
            carAddForm.Show();
        }

        private void cmbMake_SelectedIndexChanged(object sender, EventArgs e)
        {
            using var db = new Car1DealerContext();

            string a = cmbMake.SelectedItem.ToString();

            cmbModel.Items.Clear();

            foreach (var item in GetDataOperations.GetAllModelsForMake(db, a))
            {
                cmbModel.Items.Add(item);
            }
        }

        private void btnAddData_Click(object sender, EventArgs e)
        {
            AddData addData = new AddData();
            addData.Show();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            using var db = new Car1DealerContext();

            cmbMake.Items.Clear();
            cmbModel.Items.Clear();
            cmbType.Items.Clear();
            cmbFuel.Items.Clear();
            cmbGearbox.Items.Clear();
            cmbDoors.Items.Clear();
            txtMaxHp.Clear();
            txtMaxPrice.Clear();
            txtMinHp.Clear();
            txtMinPrice.Clear();

            cmbMake.Items.Add("(no)");
            foreach (var item in GetDataOperations.GetAllMakes(db))
            {
                cmbMake.Items.Add(item);
            }

            cmbModel.Items.Clear();

            cmbFuel.Items.Add("(no)");
            foreach (var item in GetDataOperations.GetAllFuels(db))
            {
                cmbFuel.Items.Add(item);
            }

            cmbGearbox.Items.Add("(no)");
            foreach (var item in GetDataOperations.GetAllGearboxs(db))
            {
                cmbGearbox.Items.Add(item);
            }

            cmbDoors.Items.Add("(no)");
            foreach (var item in GetDataOperations.GetAllDoors(db))
            {
                cmbDoors.Items.Add(item);
            }

            cmbType.Items.Add("(no)");
            foreach (var item in GetDataOperations.GetAllTypes(db))
            {
                cmbType.Items.Add(item);
            }

        }

        private void btnExtras_Click_1(object sender, EventArgs e)
        {
            extrasForm.Show();
        }




        //----add message box with info for current car ID

        //MessageBox.Show($"Current car Id is: {Form1.carId}");


        //----show/hide form

        //Form2 f2 = new Form2();
        //f2.Show();
        //this.Hide();



        //----message box

        //MessageBox.Show("You are not Logged in!");
        //textBox1.Clear();



        //----add to flowLayoutPanel

        //Button newButton = new Button();
        //newButton.Size = new Size(200, 80);
        //newButton.Name = textBox1.Text;
        //flowLayoutPanel1.Controls.Add(newButton);
        //textBox1.Clear();


        //----preselect dropDown item

        //cmbMake.SelectedIndex = 1;


    }
}
